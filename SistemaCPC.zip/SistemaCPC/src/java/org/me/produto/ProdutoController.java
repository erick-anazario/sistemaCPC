package org.me.produto;

import java.util.List;

public class ProdutoController {
    public List listarProduto() {
        List lista = null;
        return lista;
    }
    
    public void cadastrarProduto(Produto pro) {
        
    }
    
    public void alterarProduto(Produto pro) {
        
    }
    
    public void buscarProduto(Produto pro) {
        
    }
    
    public void excluirProduto(Produto pro) {
        
    }
}
