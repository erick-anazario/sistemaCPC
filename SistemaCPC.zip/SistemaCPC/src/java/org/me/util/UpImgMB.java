package org.me.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Scanner;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

@ManagedBean
public class UpImgMB {

    private Part arquivo;
    private static final String SAVE_DIR_CATEGORIA = "\\imagens\\categorias";
    private static final String SAVE_DIR_PRODUTO = "\\imagens\\produtos";
    public static String urlCat = "";

    public void importaCat() {
        try {

            String contentType = arquivo.getContentType();
            System.out.println(contentType);
            String fileName = arquivo.getSubmittedFileName();
            System.out.println(fileName);
            long fileSize = arquivo.getSize();
            System.out.println(fileSize);
            
            String currentTime = String.valueOf(DATE.getDate().getTime());
            fileName = MD5.encode(fileName+currentTime)+"."+fileName.split("[.]")[1];
            

            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            String appPath = request.getServletContext().getRealPath("");
            
            System.out.println(appPath);

            String savePath = appPath + SAVE_DIR_CATEGORIA ;
            System.out.println(savePath);
            File fileSaveDir = new File(savePath);
            fileSaveDir.mkdir();

            InputStream input = arquivo.getInputStream();
            
            Files.copy(input, new File(savePath + File.separator + fileName).toPath());
            
            pegarUrlCat(savePath + File.separator + fileName);
         
            
            //File fileDelete = new File(savePath + File.separator + "teste.pdf");
           // fileDelete.delete();
            
            

        } catch (Exception error) {
            System.out.println(error.getMessage());
        }
    }
    public void importaProd() {
        try {

            String contentType = arquivo.getContentType();
            System.out.println(contentType);
            String fileName = arquivo.getSubmittedFileName();
            System.out.println(fileName);
            long fileSize = arquivo.getSize();
            System.out.println(fileSize);
            
            String currentTime = String.valueOf(DATE.getDate().getTime());
            fileName = MD5.encode(fileName+currentTime)+"."+fileName.split("[.]")[1];
            

            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            String appPath = request.getServletContext().getRealPath("");
            
            System.out.println(appPath);

            String savePath = appPath + SAVE_DIR_PRODUTO ;
            System.out.println(savePath);
            File fileSaveDir = new File(savePath);
            fileSaveDir.mkdir();

            InputStream input = arquivo.getInputStream();
            
            Files.copy(input, new File(savePath + File.separator + fileName).toPath());
            
            
           //File fileDelete = new File(savePath + File.separator + "teste.pdf");
            //fileDelete.delete();
            
            
            

        } catch (Exception error) {
            System.out.println(error.getMessage());
        }
    }
    
    public void pegarUrlCat(String url){
            
    }

    public Part getArquivo() {
        return arquivo;
    }

    public void setArquivo(Part arquivo) {
        this.arquivo = arquivo;
    }

}
