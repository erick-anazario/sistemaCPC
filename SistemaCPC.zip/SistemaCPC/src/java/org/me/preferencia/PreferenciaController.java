package org.me.preferencia;

import java.util.List;

public class PreferenciaController {
    public List listarPreferencia() {
        List lista = null;
        return lista;
    }
    
    public void cadastrarPreferencia(Preferencia pre) {
        
    }
    
    public void alterarPreferencia(Preferencia pre) {
        
    }
    
    public void buscarPreferencia(Preferencia pre) {
        
    }
    
    public void excluirPreferencia(Preferencia pre) {
        
    }
}
