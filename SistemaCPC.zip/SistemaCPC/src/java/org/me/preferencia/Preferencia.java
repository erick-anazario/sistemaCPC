package org.me.preferencia;

public class Preferencia {
    private int id;
    private int idproduto;
    private int idcliente;
    private String data_pref;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdproduto() {
        return idproduto;
    }

    public void setIdproduto(int idproduto) {
        this.idproduto = idproduto;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getData_pref() {
        return data_pref;
    }

    public void setData_pref(String data_pref) {
        this.data_pref = data_pref;
    }
    
}
