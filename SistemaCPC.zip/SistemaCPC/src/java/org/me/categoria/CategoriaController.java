package org.me.categoria;

import java.util.List;

public class CategoriaController {
    public List listarCategoria() {
        List lista = null;
        return lista;
    }
    
    public void cadastrarCategoria(Categoria cat) {
        
    }
    
    public void alterarCategoria(Categoria cat) {
        
    }
    
    public void buscarCategoria(Categoria cat) {
        
    }
    
    public void excluirCategoria(Categoria cat) {
        
    }
}