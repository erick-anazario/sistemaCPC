package org.me.usuario;

import java.sql.ResultSet;
import org.me.database.Database;
import org.me.exception.ExceptionError;

public class UsuarioDAO {
        public Usuario login(Usuario usuario) throws ExceptionError {
        Usuario retorno = null;
        try {
            Database myDb = new Database();

            String sql = "SELECT * FROM usuario WHERE nome = ? AND senha = MD5(?)";
            myDb.setQuerySql(sql);

            myDb.setQueryParameter().setString(1, usuario.getNome());
            myDb.setQueryParameter().setString(2, usuario.getSenha());

       
            ResultSet myResult = myDb.setQueryParameter().executeQuery();

            if (myResult.next()) {
                Usuario usuarioLogado = new Usuario();
                usuarioLogado.setId(myResult.getInt("id"));
                usuarioLogado.setNome(myResult.getString("nome"));
                usuarioLogado.setSenha(myResult.getString("senha"));

                
                retorno = usuarioLogado;
                
            }
        } catch (ExceptionError error) {
            throw new ExceptionError(error);
        } catch (Exception error) {
            throw new ExceptionError(error);
        }
        return retorno;
    }
}
