package org.me.usuario;

/*
NÃO ESQUECER DE ALTERAR AS STRINGS DO MB ABAIXO!!!
*/
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.RequestScoped;
import org.me.exception.ExceptionError;
import org.me.util.MessageMB;
import org.me.util.RedirectMB;
import org.me.util.SessionMB;

@ManagedBean(name = "userMB")
@SessionScoped

public class UsuarioMB {

    private SessionMB sessionMB = new SessionMB();
    private Usuario user = new Usuario();

    public UsuarioMB() {
        System.out.println("Estou no construtor");
    }

    public Usuario getUsuario() {
        return user;
    }

    public void setUsuario(Usuario user) {
        this.user = user;
    }

    public void login() throws IOException {
        try {
            UsuarioController usuarioController = new UsuarioController();

            Usuario userLogado = usuarioController.login(this.user);
            
            if (userLogado!=null) {
                
                

                boolean auth = true;
                sessionMB.setAttribute("auth", auth);

                String url = "/site/index.xhtml";
                new RedirectMB(url);
            } else {
                new MessageMB("msgInfo", "Usuário ou Senha inválidos!", "", 3);
                //return null;
            }
        } catch (ExceptionError error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

    }

    public void cadastrar() throws IOException {
        try {
            UsuarioController usuarioController = new UsuarioController();

            if (usuarioController.cadastrar(this.user)) {

                boolean auth = true;
                sessionMB.setAttribute("auth", auth);

                String url = "/site/user/cadastrar_ok.xhtml";
                new RedirectMB(url);
            } else {
                new MessageMB("msgInfo", "Usuário não cadastrado!", "", 3);
                //return null;
            }
        } catch (ExceptionError error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

    }

    public void buscar() throws IOException {
        try {
            UsuarioController usuarioController = new UsuarioController();

            Usuario buscarUsuario = usuarioController.buscar(this.user);

            if (buscarUsuario.getId() != 0) {
                setUsuario(buscarUsuario);
            } else {
                new MessageMB("msgInfo", "Usuário não encontrado!", "", 3);
                //return null;
            }
        } catch (ExceptionError error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

    }

    public void buscar(Usuario user) throws IOException {
        try {

            setUsuario(user);
            String url = "/site/user/alterar.xhtml";

            new RedirectMB(url);
            System.out.println(user.getNome());

        } catch (Exception error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

    }

    public void alterar() throws IOException {
        try {
            UsuarioController usuarioController = new UsuarioController();

            if (usuarioController.alterar(this.user)) {

                boolean auth = true;
                sessionMB.setAttribute("auth", auth);

                String url = "/site/user/alterar_ok.xhtml";
                new RedirectMB(url);
            } else {
                new MessageMB("msgInfo", "Usuário não alterado!", "", 3);
                //return null;
            }
        } catch (ExceptionError error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

    }

    public List<Usuario> listar() throws IOException {
        List userList = new ArrayList<Usuario>();

        try {
            UsuarioController usuarioController = new UsuarioController();

            userList = usuarioController.listar();

        } catch (ExceptionError error) {
            new MessageMB("msgInfo", error.getMessage(), "", 4);
        }

        return userList;
    }
    
    public Usuario getSessionUsuario(String user) {
        return (Usuario) sessionMB.getAttribute("user");
    }
    
    public void userSeguranca() {
        
        Object logado = (boolean)sessionMB.getAttribute("auth");
        
        if(logado==null) {
            String url = "/index.xhtml";
        new RedirectMB(url);
        }
    }
}
