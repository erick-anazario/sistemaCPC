/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.preferencia;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 2017101953
 */
public class PreferenciaControllerTest {
    
    public PreferenciaControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of listarPreferencia method, of class PreferenciaController.
     */
    @Test
    public void testListarPreferencia() {
        System.out.println("listarPreferencia");
        PreferenciaController instance = new PreferenciaController();
        List expResult = null;
        List result = instance.listarPreferencia();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cadastrarPreferencia method, of class PreferenciaController.
     */
    @Test
    public void testCadastrarPreferencia() {
        System.out.println("cadastrarPreferencia");
        Preferencia pre = null;
        PreferenciaController instance = new PreferenciaController();
        instance.cadastrarPreferencia(pre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of alterarPreferencia method, of class PreferenciaController.
     */
    @Test
    public void testAlterarPreferencia() {
        System.out.println("alterarPreferencia");
        Preferencia pre = null;
        PreferenciaController instance = new PreferenciaController();
        instance.alterarPreferencia(pre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarPreferencia method, of class PreferenciaController.
     */
    @Test
    public void testBuscarPreferencia() {
        System.out.println("buscarPreferencia");
        Preferencia pre = null;
        PreferenciaController instance = new PreferenciaController();
        instance.buscarPreferencia(pre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of excluirPreferencia method, of class PreferenciaController.
     */
    @Test
    public void testExcluirPreferencia() {
        System.out.println("excluirPreferencia");
        Preferencia pre = null;
        PreferenciaController instance = new PreferenciaController();
        instance.excluirPreferencia(pre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
