/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.produto;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 2017101953
 */
public class ProdutoControllerTest {
    
    public ProdutoControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of listarProduto method, of class ProdutoController.
     */
    @Test
    public void testListarProduto() {
        System.out.println("listarProduto");
        ProdutoController instance = new ProdutoController();
        List expResult = null;
        List result = instance.listarProduto();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cadastrarProduto method, of class ProdutoController.
     */
    @Test
    public void testCadastrarProduto() {
        System.out.println("cadastrarProduto");
        Produto pro = null;
        ProdutoController instance = new ProdutoController();
        instance.cadastrarProduto(pro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of alterarProduto method, of class ProdutoController.
     */
    @Test
    public void testAlterarProduto() {
        System.out.println("alterarProduto");
        Produto pro = null;
        ProdutoController instance = new ProdutoController();
        instance.alterarProduto(pro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarProduto method, of class ProdutoController.
     */
    @Test
    public void testBuscarProduto() {
        System.out.println("buscarProduto");
        Produto pro = null;
        ProdutoController instance = new ProdutoController();
        instance.buscarProduto(pro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of excluirProduto method, of class ProdutoController.
     */
    @Test
    public void testExcluirProduto() {
        System.out.println("excluirProduto");
        Produto pro = null;
        ProdutoController instance = new ProdutoController();
        instance.excluirProduto(pro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
