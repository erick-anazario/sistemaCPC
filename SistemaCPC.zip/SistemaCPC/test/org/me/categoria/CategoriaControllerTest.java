/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.categoria;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 2017101953
 */
public class CategoriaControllerTest {
    
    public CategoriaControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of listarCategoria method, of class CategoriaController.
     */
    @Test
    public void testListarCategoria() {
        System.out.println("listarCategoria");
        CategoriaController instance = new CategoriaController();
        List expResult = null;
        List result = instance.listarCategoria();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cadastrarCategoria method, of class CategoriaController.
     */
    @Test
    public void testCadastrarCategoria() {
        System.out.println("cadastrarCategoria");
        Categoria cat = null;
        CategoriaController instance = new CategoriaController();
        instance.cadastrarCategoria(cat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of alterarCategoria method, of class CategoriaController.
     */
    @Test
    public void testAlterarCategoria() {
        System.out.println("alterarCategoria");
        Categoria cat = null;
        CategoriaController instance = new CategoriaController();
        instance.alterarCategoria(cat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarCategoria method, of class CategoriaController.
     */
    @Test
    public void testBuscarCategoria() {
        System.out.println("buscarCategoria");
        Categoria cat = null;
        CategoriaController instance = new CategoriaController();
        instance.buscarCategoria(cat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of excluirCategoria method, of class CategoriaController.
     */
    @Test
    public void testExcluirCategoria() {
        System.out.println("excluirCategoria");
        Categoria cat = null;
        CategoriaController instance = new CategoriaController();
        instance.excluirCategoria(cat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
