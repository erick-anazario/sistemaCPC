/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function mostrarFormulario(id){
    document.getElementById(id).style.display='block';
    document.getElementById(id).style.transition='.5s';
    document.getElementById('menuAdm').style.display='none';
    document.getElementById('btnVoltar').style.display='block';
}

function mostrarMenu(){
    document.getElementById('menuAdm').style.display='block';
    document.getElementById('btnVoltar').style.display='none';
    document.getElementById('formCliente').style.display='none';
    document.getElementById('formCategoria').style.display='none';
    document.getElementById('formProduto').style.display='none';
    
}

function mostraMiniatura(srcImg, destImg){
    
    dest = document.getElementById(destImg);
    
    
    dest.src = "C:\Users\2017202787\Downloads\download.jpg";
    alert(srcImg.value);
   
   
    
}


